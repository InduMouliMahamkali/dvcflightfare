from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="its a flightfare package",
    author="indu mouli",
    packages=find_packages(),
    License="MIT"
)
